from matplotlib import pyplot as plt

x = range(4)
y = range(4)

plt.plot(x, y, '.-')
plt.xlabel('Test loss ')
plt.ylabel('Test loss')
plt.show()
