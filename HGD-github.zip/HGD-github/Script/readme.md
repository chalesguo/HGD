Main training function:
train_once: Unipolar structure
train_low: Low level
train_mid: Intermediate level
train_high: High level 

Test code:
test_initial: Similarity of unregistered image pairs
test_one: Test single level
test_all: Test multi-resolution structure 

Resection:
test_first, test_second: Conduct separate tests for the first and second levels of registration.
